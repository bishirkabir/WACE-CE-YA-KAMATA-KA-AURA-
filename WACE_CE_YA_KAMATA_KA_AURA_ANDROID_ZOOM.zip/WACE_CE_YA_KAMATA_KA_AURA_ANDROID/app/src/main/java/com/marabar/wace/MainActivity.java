package com.marabar.wace;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.graphics.Matrix;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(235, 235, 235));
        ProgressBar progress = new ProgressBar(this);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(progress, progressParams);
        setContentView(root);
        try {
            File pdfFile = new File(getCacheDir(), "littafi.pdf");
            if (!pdfFile.exists() || pdfFile.length() == 0) {
                try (InputStream input = getAssets().open("littafi.pdf");
                     FileOutputStream output = new FileOutputStream(pdfFile)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                }
            }
            descriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            recyclerView = new RecyclerView(this);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(new PdfPageAdapter());
            root.removeAllViews();
            root.addView(recyclerView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Exception e) {
            Toast.makeText(this, "An kasa bude littafin: " + e.getMessage(), Toast.LENGTH_LONG).show();
            TextView error = new TextView(this);
            error.setText("An kasa bude littafin. Ka sake bude manhajar.");
            error.setGravity(Gravity.CENTER);
            root.removeAllViews();
            root.addView(error);
        }
    }

    private class PdfPageAdapter extends RecyclerView.Adapter<PdfPageAdapter.PageHolder> {
        @Override public PageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ZoomImageView image = new ZoomImageView(MainActivity.this);
            image.setBackgroundColor(Color.WHITE);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setAdjustViewBounds(true);
            image.setPadding(5, 5, 5, 5);
            return new PageHolder(image);
        }
        @Override public void onBindViewHolder(PageHolder holder, int position) {
            try (PdfRenderer.Page page = renderer.openPage(position)) {
                int width = Math.max(800, (getResources().getDisplayMetrics().widthPixels - 16) * 2);
                int height = Math.max(1, (int) (width * (page.getHeight() / (float) page.getWidth())));
                Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                holder.image.setImageBitmap(bitmap);
                holder.image.resetZoom();
                holder.image.setContentDescription("Shafi na " + (position + 1));
            } catch (Exception e) {
                holder.image.setImageDrawable(null);
            }
        }
        @Override public int getItemCount() { return renderer.getPageCount(); }
        class PageHolder extends RecyclerView.ViewHolder {
            ZoomImageView image;
            PageHolder(ZoomImageView view) { super(view); image = view; }
        }
    }


    // Supports pinch-to-zoom and dragging while zoomed in.
    private class ZoomImageView extends ImageView {
        private final ScaleGestureDetector scaleDetector;
        private final Matrix matrix = new Matrix();
        private float scale = 1f;
        private float lastX, lastY;
        private boolean dragging = false;

        ZoomImageView(android.content.Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override public boolean onScale(ScaleGestureDetector detector) {
                        float next = Math.max(1f, Math.min(4f, scale * detector.getScaleFactor()));
                        float factor = next / scale;
                        matrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                        scale = next;
                        setImageMatrix(matrix);
                        return true;
                    }
                });
        }

        void resetZoom() {
            scale = 1f;
            matrix.reset();
            setImageMatrix(matrix);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    dragging = false;
                    return scale > 1f || super.onTouchEvent(event);
                case MotionEvent.ACTION_MOVE:
                    if (scale > 1f && !scaleDetector.isInProgress()) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        matrix.postTranslate(dx, dy);
                        setImageMatrix(matrix);
                        dragging = true;
                    }
                    lastX = event.getX();
                    lastY = event.getY();
                    return scale > 1f;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (scale > 1f) {
                        performClick();
                        return true;
                    }
                    return super.onTouchEvent(event);
                default:
                    return scale > 1f;
            }
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (renderer != null) renderer.close();
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) {}
    }
}
