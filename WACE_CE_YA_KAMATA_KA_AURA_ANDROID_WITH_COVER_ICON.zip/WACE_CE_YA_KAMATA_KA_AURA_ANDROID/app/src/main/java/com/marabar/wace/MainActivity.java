package com.marabar.wace;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(235, 235, 235));
        ProgressBar progress = new ProgressBar(this);
        root.addView(progress, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setContentView(root);
        try {
            File pdfFile = new File(getCacheDir(), "littafi.pdf");
            if (!pdfFile.exists() || pdfFile.length() == 0) {
                try (InputStream input = getAssets().open("littafi.pdf");
                     FileOutputStream output = new FileOutputStream(pdfFile)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                }
            }
            descriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            recyclerView = new RecyclerView(this);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(new PdfPageAdapter());
            root.removeAllViews();
            root.addView(recyclerView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Exception e) {
            Toast.makeText(this, "An kasa bude littafin: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            TextView error = new TextView(this);
            error.setText("An kasa bude littafin. Ka sake bude manhajar.");
            error.setGravity(Gravity.CENTER);
            root.removeAllViews();
            root.addView(error);
        }
    }

    private class PdfPageAdapter extends RecyclerView.Adapter<PdfPageAdapter.PageHolder> {
        @Override
        public PageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ZoomImageView image = new ZoomImageView(MainActivity.this);
            image.setBackgroundColor(Color.WHITE);
            image.setPadding(5, 5, 5, 5);
            return new PageHolder(image);
        }

        @Override
        public void onBindViewHolder(PageHolder holder, int position) {
            try (PdfRenderer.Page page = renderer.openPage(position)) {
                int width = Math.max(1200, (getResources().getDisplayMetrics().widthPixels - 16) * 3);
                int height = Math.max(1, (int) (width * (page.getHeight() / (float) page.getWidth())));
                Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                holder.image.setImageBitmap(bitmap);
                holder.image.setContentDescription("Shafi na " + (position + 1));
                holder.image.post(holder.image::resetZoom);
            } catch (Exception e) {
                holder.image.setImageDrawable(null);
            }
        }

        @Override public int getItemCount() { return renderer.getPageCount(); }

        class PageHolder extends RecyclerView.ViewHolder {
            ZoomImageView image;
            PageHolder(ZoomImageView view) {
                super(view);
                image = view;
            }
        }
    }

    private class ZoomImageView extends ImageView {
        private final ScaleGestureDetector scaleDetector;
        private final Matrix displayMatrix = new Matrix();
        private final Matrix fitMatrix = new Matrix();
        private float zoom = 1f;
        private float lastX, lastY;
        private boolean moved;

        ZoomImageView(android.content.Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            setFocusable(true);
            scaleDetector = new ScaleGestureDetector(context,
                    new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float next = Math.max(1f, Math.min(5f, zoom * detector.getScaleFactor()));
                    float factor = next / zoom;
                    displayMatrix.postScale(factor, factor,
                            detector.getFocusX(), detector.getFocusY());
                    zoom = next;
                    setImageMatrix(displayMatrix);
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }
            });
        }

        void resetZoom() {
            if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) return;
            float dw = getDrawable().getIntrinsicWidth();
            float dh = getDrawable().getIntrinsicHeight();
            if (dw <= 0 || dh <= 0) return;
            float scale = Math.min((getWidth() - getPaddingLeft() - getPaddingRight()) / dw,
                    (getHeight() - getPaddingTop() - getPaddingBottom()) / dh);
            float dx = (getWidth() - dw * scale) / 2f;
            float dy = (getHeight() - dh * scale) / 2f;
            fitMatrix.reset();
            fitMatrix.setScale(scale, scale);
            fitMatrix.postTranslate(dx, dy);
            displayMatrix.set(fitMatrix);
            zoom = 1f;
            setImageMatrix(displayMatrix);
            invalidate();
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            resetZoom();
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            int action = event.getActionMasked();
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (zoom > 1.01f && !scaleDetector.isInProgress()
                            && event.getPointerCount() == 1) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        displayMatrix.postTranslate(dx, dy);
                        setImageMatrix(displayMatrix);
                        moved = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    lastX = event.getX();
                    lastY = event.getY();
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    lastX = event.getX(0);
                    lastY = event.getY(0);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    getParent().requestDisallowInterceptTouchEvent(false);
                    performClick();
                    return true;
                default:
                    return true;
            }
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (renderer != null) renderer.close();
        try {
            if (descriptor != null) descriptor.close();
        } catch (Exception ignored) {}
    }
}
